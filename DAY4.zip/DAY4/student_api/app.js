const express = require("express");
const app = express();

app.use(express.json());
    
    
let students = [{ id: 1, name: "Rahul", course: "BCA" },
                    { id: 2, name: "ADITYA", course: "MBBS" }
    ];

//api 
app.get('/students',(req, res) => {
    res.json(students)
})




app.listen(3000, () => {
console.log("Server running on port 3000");
})//start server on port number 3000