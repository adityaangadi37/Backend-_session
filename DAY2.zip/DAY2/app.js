// JS - to make website more interactive,more response and add functionality
// Programming Lang -
// FE - High level => (v8-engine)Low level
// BE - JS -> nodejs
// in.java -> javac in.java => in.class(byte) => java in => mc => o/p
console.log("Hello universe")

let x = 10;
console.log(x)

let name = "Aditya";
console.log(name)

let x1 = true;

console.log(typeof(x1)) 

var arr = [1,2,3,4]
var arr = [1,2,3,"Hello"]
console.log((arr));
console.log((arr));

let r = undefined;
console.log(r);

let student1 = { stdname: "xyz", 
    reg_no : 1234 ,
    hobbies : ["music","movies"]
}
console.log(student1)
console.log("student 1 name:",student1.std_name);
//function is a block of code which is used to perform specific task
//simple function
function add(x,y){
    return x+y
}
console.log(add(2,4));

//function without name
console.log(function(x,y){return x+y}(4,3));

//Arrow function
var fun1 = (x,y)=>{return x+y;};
console.log(fun1(6,5));

//call back function
8310907792