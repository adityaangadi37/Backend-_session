const http = require('http'); 
const server = http.createServer(
function(req, res) {
    console.log(req);
    if(req.url === '/'){    
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('Home Page !');
    }
    else if (req.url === '/about'){
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('About Page !');
    }
    else if(req.url === '/contact'){
         res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('Contact Page !');
    }
    else{
         res.writeHead(404, {'Content-Type': 'text/plain'});
    res.end('404 not found');
    }

});
// ← LISTEN: Start server on port 3000
server.listen(3000, function() {       
console.log('Server running at http://localhost:3000/');
})