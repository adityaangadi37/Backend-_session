const express = require('express');
const app = express()
//amazom.com
//http method = get 
//route = /
app.get('/',(req,res)=>{
res.send("Home Page");
}
)
//route = /about
app.get('/about',(req,res)=>{
res.send("About Page 💥💥");
}
)

//route = /contact
app.get('/contact',(req,res)=>{
res.send("contact Page 🫙");
}
)

//route = /profile
app.get('/profile',(req,res)=>{
res.send("profile page 🧑🏻‍⚖️");
}
)

app.listen(3000,()=>{ console.log("running on port 3000 🎲")})