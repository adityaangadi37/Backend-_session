const express = require('express');
const app = express();

app.get('/', (req, res) => {
res.send('Hello from Express!');
});

app.get('/about', (req, res) => {
res.send('About page!');
});


app.listen(8080, () => {
console.log('Server running on port 8080!');
})